create database hotel;
use hotel; 
create table Reserva_Quartos
(
   Sigla_Hotel   varchar(10)   not null,
   Numero_Quarto   Integer   not null,
   Numero_Reserva   Integer   not null,
   Cama_Extra   Integer   null,
   Numero_Pessoas   Integer   null,
 
   constraint PK_Reserva_Quartos primary key (Sigla_Hotel, Numero_Quarto, Numero_Reserva)
);
 
create table Hotel
(
   Sigla_Hotel   varchar(10)   not null,
   Designacao   varchar(100)   null,
 
   constraint PK_Hotel primary key (Sigla_Hotel)
);
 
create table Quarto
(
   Sigla_Hotel   varchar(10)   not null,
   Numero_Quarto   Integer   not null,
   Numero_Camas   Integer   null,
   Preco   decimal(5,2)   null,
 
   constraint PK_Quarto primary key (Sigla_Hotel, Numero_Quarto)
);
 
create table Reserva
(
   Numero_Cliente   Integer   not null,
   Numero_Reserva   Integer   not null,
   Dia_Entrada   datetime   null,
   Dia_Saida   datetime   null,
 
   constraint PK_Reserva primary key (Numero_Reserva)
);
 
create table Cliente
(
   Numero_Cliente   Integer   not null,
   Nome_Cliente   varchar(100)   null,
 
   constraint PK_Cliente primary key (Numero_Cliente)
);
 
create table Individual
(
   Numero_Cliente   Integer   not null,
   BI   Integer   null,
 
   constraint PK_Individual primary key (Numero_Cliente)
);
 
create table Organizacao
(
   Numero_Cliente   Integer   not null,
   Ramo_Actividade   varchar(100)   null,
   Nome_Contacto   varchar(100)   null,
 
   constraint PK_Organizacao primary key (Numero_Cliente)
);
 
create table Factura
(
   Numero_Reserva   Integer   not null,
   Numero_Factura   Integer   not null,
   Data_Factura   datetime   null,
   Valor_Factura   decimal(8,2)   null,
 
   constraint PK_Factura primary key (Numero_Factura)
);
 
alter table Reserva_Quartos
   add constraint FK_Quarto_Reserva_Quartos_Reserva foreign key (Sigla_Hotel, Numero_Quarto)
   references Quarto(Sigla_Hotel, Numero_Quarto)
   on delete cascade
   on update cascade
; 
alter table Reserva_Quartos
   add constraint FK_Reserva_Reserva_Quartos_Quarto foreign key (Numero_Reserva)
   references Reserva(Numero_Reserva)
   on delete cascade
   on update cascade
;
 
 
alter table Quarto
   add constraint FK_Quarto_HotelQuarto_Hotel foreign key (Sigla_Hotel)
   references Hotel(Sigla_Hotel)
   on delete cascade
   on update cascade
;
 
alter table Reserva
   add constraint FK_Reserva_ClienteReserva_Cliente foreign key (Numero_Cliente)
   references Cliente(Numero_Cliente)
   on delete restrict
   on update cascade
;
 
 
alter table Individual
   add constraint FK_Individual_Cliente foreign key (Numero_Cliente)
   references Cliente(Numero_Cliente)
   on delete cascade
   on update cascade
;
 
alter table Organizacao
   add constraint FK_Organizacao_Cliente foreign key (Numero_Cliente)
   references Cliente(Numero_Cliente)
   on delete cascade
   on update cascade
;
 
alter table Factura
   add constraint FK_Factura_FacturaReserva_Reserva foreign key (Numero_Reserva)
   references Reserva(Numero_Reserva)
   on delete restrict
   on update cascade
;
 
 
 delete from factura;
delete from reserva_quartos;
delete from reserva;
delete from individual;
delete from organizacao;
delete from cliente;
delete from quarto;
delete from hotel;

insert into hotel (sigla_hotel, designacao) values ('SH', 'Sheraton');
insert into hotel (sigla_hotel, designacao) values ('AL', 'Alfa');
insert into hotel (sigla_hotel, designacao) values ('MN', 'Mundial');
insert into hotel (sigla_hotel, designacao) values ('RM', 'Roma');
insert into hotel (sigla_hotel, designacao) values ('MJ', 'Majestic');
insert into hotel (sigla_hotel, designacao) values ('LS', 'Lisboa');
insert into hotel (sigla_hotel, designacao) values ('BH', 'Baia');

insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 1, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 2, 2, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 3, 4, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 4, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 5, 2, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 6, 3, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 7, 2, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 8, 4, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 9, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('SH', 10, 1, 5);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 1, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 2, 4, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 3, 4, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 4, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 5, 2, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 6, 4, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 7, 2, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('AL', 8, 4, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 1, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 2, 2, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 3, 4, 26);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 4, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 5, 3, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 6, 4, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 7, 2, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 8, 4, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 9, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 10, 2, 8);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 11, 3, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MN', 12, 1, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 1, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 2, 3, 25);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 3, 4, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 4, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 5, 2, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 6, 2, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 7, 2, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 8, 4, null);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 9, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('RM', 10, 4, 13);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MJ', 1, 2, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MJ', 2, 3, 15);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MJ', 3, 4, 22);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('MJ', 4, 1, 10);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 1, 2, 12);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 2, 2, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 3, 3, 16);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 4, 1, 14);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 5, 1, 20);
insert into Quarto (sigla_hotel, numero_quarto, Numero_Camas, Preco) values ('LS', 6, 4, 20);

insert into cliente (numero_cliente, nome_cliente) values (1,'Ana');
insert into cliente (numero_cliente, nome_cliente) values (2,'ISCTE');
insert into cliente (numero_cliente, nome_cliente) values (3,'Pedro');
insert into cliente (numero_cliente, nome_cliente) values (4,'ONU');
insert into cliente (numero_cliente, nome_cliente) values (5,'Luis');
insert into cliente (numero_cliente, nome_cliente) values (6,'NASA');
insert into cliente (numero_cliente, nome_cliente) values (7,'Carlos');
insert into cliente (numero_cliente, nome_cliente) values (8,'CE');
insert into cliente (numero_cliente, nome_cliente) values (9,'Sofia');
insert into cliente (numero_cliente, nome_cliente) values (10,'TAP');
insert into cliente (numero_cliente, nome_cliente) values (11,'Luisa');
insert into cliente (numero_cliente, nome_cliente) values (12,'Antonio');
insert into cliente (numero_cliente, nome_cliente) values (13,'Continente');


insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (2, null, 'Ensino');
insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (4, 'Evaristo', 'Internacional');
insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (6, null, 'Defesa');
insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (8, 'Joao', 'Governa  o');
insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (10, null, 'Transportes');
insert into organizacao (numero_cliente, Nome_Contacto, Ramo_Actividade) values (13, null, 'Alimentar');

insert into Individual (numero_cliente, BI) values (1, 589595);
insert into Individual (numero_cliente, BI) values (3, 585985);
insert into Individual (numero_cliente, BI) values (5, 375895);
insert into Individual (numero_cliente, BI) values (7, 836137);
insert into Individual (numero_cliente, BI) values (9, 767676);
insert into Individual (numero_cliente, BI) values (11, null);
insert into Individual (numero_cliente, BI) values (12, null);



insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (1,4,'2012-07-17', '2012-07-19');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (2,4,'2012-07-17', '2012-07-18');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (3,1,'2012-07-18', '2012-07-21');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (4,2,'2012-07-18', '2012-07-21');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (5,2,'2012-06-17', '2012-06-17');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (6,4,'2012-06-17', '2012-06-11');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (7,2,'2012-06-17', '2012-06-18');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (8,3,'2012-06-17', '2012-06-18');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (9,3,'2012-09-10', '2012-09-12');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (10,4,'2012-09-11', '2012-09-13');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (11,4,'2012-08-12', '2012-08-15');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (12,4,'2012-08-13', '2012-08-14');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (13,4,'2012-08-14', '2012-08-19');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (14,4,'2012-08-17', '2012-08-21');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (15,5,'2012-06-18', '2012-06-28');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (16,5,'2012-06-21', '2012-06-22');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (17,5,'2012-06-20', '2012-06-25');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (18,8,'2012-06-17', '2012-06-18');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (19,8,'2012-06-17', '2012-06-19');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (20,9,'2012-05-17', '2012-05-20');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (21,9,'2012-05-01', '2012-05-11');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (22,10,'2012-05-02', '2012-05-04');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (23,10,'2012-05-01', '2012-05-03');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (24,11,'2012-04-10', '2012-04-13');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (25,11,'2012-04-10', '2012-04-13');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (26,11,'2012-04-09', '2012-04-12');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (27,12,'2012-06-20', '2012-06-28');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (28,12,'2012-03-21', '2012-03-22');
insert into reserva (numero_reserva, numero_cliente, dia_entrada, dia_saida) values (29,12,'2012-03-17', '2012-03-18');


insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (1,'SH',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (1,'SH',3, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (2,'AL',4, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (2,'AL',6, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (3,'AL',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (4,'AL',2, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (5,'AL',7, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (6,'AL',8, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (7,'MN',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (8,'MN',2, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (9,'MN',7, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (10,'LS',6, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (11,'MN',3, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (12,'RM',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (13,'MJ',2, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (14,'RM',3, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (15,'RM',4, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (16,'RM',5, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (17,'RM',7, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (18,'RM',8, null,3);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (19,'RM',9, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (20,'RM',10, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (21,'MJ',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (22,'MJ',2, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (23,'MJ',3, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (24,'MJ',4, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (25,'LS',1, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (26,'LS',2, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (27,'LS',3, null,3);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (28, 'LS',4, null,2);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (29,'LS',5, null,1);
insert into reserva_quartos (numero_reserva, sigla_hotel, numero_quarto, Cama_Extra, Numero_Pessoas) values (29,'LS',6, null,1);

insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (1,1,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (2,3,'2012-11-17',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (3,5,'2012-12-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (4,6,'2012-09-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (5,8,'2012-11-11',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (6,10,'2012-11-10',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (7,12,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (8,13,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (9,14,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (10,16,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (11,17,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (12,20,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (13,21,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (14,25,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (15,27,'2012-11-18',400);
insert into factura (numero_factura, numero_reserva, data_factura, valor_factura) values (16,29,'2012-11-18',400);



update factura set valor_factura =400;